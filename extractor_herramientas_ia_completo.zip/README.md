# 🤖 Extractor Automático de Herramientas de IA

## 📋 Descripción

Sistema automático que extrae diariamente las mejores herramientas de Inteligencia Artificial y las guarda en Google Sheets, sin duplicados y completamente gratis.

## ✨ Características

- ✅ **Extracción automática diaria** de herramientas de IA
- ✅ **Sin duplicados** - sistema inteligente de detección
- ✅ **Completamente gratis** - usa GitHub Actions y Google Sheets API
- ✅ **Fácil configuración** - guía paso a paso incluida
- ✅ **Respaldos automáticos** - archivos CSV y JSON
- ✅ **Robusto y confiable** - manejo de errores incluido

## 🎯 Fuentes de Datos

- **FutureTools.io** - Herramientas de IA más populares
- **Toolify.ai** - Directorio completo de herramientas IA
- *Más fuentes se pueden agregar fácilmente*

## 🚀 Instalación Rápida

1. **Fork este repositorio**
2. **Configura Google Sheets API** (ver guía completa)
3. **Agrega credenciales como secreto** en GitHub
4. **¡Listo!** Se ejecuta automáticamente todos los días

## 📖 Guía Completa

Lee el archivo `GUIA_COMPLETA_USUARIO.md` para instrucciones detalladas paso a paso.

## 🔧 Configuración

### Variables de Entorno
- `GOOGLE_CREDENTIALS`: Credenciales de Google Sheets API (JSON)

### Personalización
- Cambiar horario de ejecución en `.github/workflows/daily_scraper.yml`
- Modificar nombre de hoja en `ai_tools_scraper_simple.py`
- Agregar nuevas fuentes editando el script principal

## 📊 Estructura de Datos

Cada herramienta incluye:
- **Nombre**: Nombre de la herramienta
- **Descripción**: Descripción breve
- **URL**: Enlace a la herramienta
- **Categoría**: Tipo de herramienta IA
- **Fuente**: Sitio web de origen
- **Fecha**: Fecha de extracción

## 🛠️ Solución de Problemas

### Errores Comunes
- **Credenciales inválidas**: Verifica el secreto GOOGLE_CREDENTIALS
- **Permisos de Google Sheets**: Comparte la hoja con el service account
- **Workflow no ejecuta**: Activa GitHub Actions en Settings

## 📈 Monitoreo

- **GitHub Actions**: Ve el estado de las ejecuciones
- **Google Sheets**: Revisa que se agreguen nuevos datos
- **Archivos de respaldo**: CSV y JSON se crean automáticamente

## 🤝 Contribuir

¡Las contribuciones son bienvenidas!

1. Fork el proyecto
2. Crea una rama para tu feature
3. Commit tus cambios
4. Push a la rama
5. Abre un Pull Request

## 📄 Licencia

Este proyecto es de código abierto y está disponible bajo la licencia MIT.

## 📞 Soporte

Si tienes problemas:
1. Revisa la guía completa
2. Consulta la sección de problemas comunes
3. Revisa los logs en GitHub Actions

---

**¡Automatiza tu investigación de herramientas IA!** 🚀

