# 🤖 GUÍA COMPLETA: Extractor Automático de Herramientas de IA

## 📋 ¿Qué es esto?

Esta guía te ayudará a configurar un sistema **completamente automático** que actualizará tu hoja de Google Sheets todos los días con las mejores herramientas de Inteligencia Artificial del mundo, **sin que tengas que hacer nada** después de la configuración inicial.

### ✨ Lo que obtendrás:
- ✅ **Actualización automática diaria** de tu Google Sheets
- ✅ **Sin duplicados** - el sistema es inteligente
- ✅ **Completamente gratis** - usa servicios gratuitos
- ✅ **No necesitas estar conectado** - funciona en la nube
- ✅ **Información en español** cuando esté disponible
- ✅ **Fácil de configurar** - solo sigues los pasos

---

## 🎯 RESUMEN RÁPIDO (Para los impacientes)

**Si quieres empezar YA, estos son los pasos básicos:**

1. **Crear cuenta en GitHub** (gratis)
2. **Configurar Google Sheets API** (gratis)
3. **Subir el código a GitHub**
4. **Configurar la automatización**
5. **¡Listo!** Tu hoja se actualiza sola todos los días

**Tiempo estimado:** 30-45 minutos la primera vez

---


## 📋 REQUISITOS PREVIOS

Antes de empezar, necesitas tener:

### ✅ Cosas que YA tienes:
- **Computadora con Ubuntu** (que ya tienes)
- **Conexión a internet** (que ya tienes)
- **Navegador web** (Firefox, Chrome, etc.)

### 📧 Cuentas que necesitas crear (GRATIS):
- **Cuenta de Google** (si no la tienes)
- **Cuenta de GitHub** (la crearemos juntos)

### ⏰ Tiempo necesario:
- **Primera configuración:** 30-45 minutos
- **Mantenimiento:** 0 minutos (es automático)

---

## 🚀 PASO 1: CREAR CUENTA EN GITHUB

GitHub es donde guardaremos nuestro código y donde se ejecutará automáticamente todos los días.

### 1.1 Ir a GitHub
1. Abre tu navegador
2. Ve a: **https://github.com**
3. Haz clic en **"Sign up"** (Registrarse)

### 1.2 Crear la cuenta
1. **Username:** Elige un nombre de usuario (ejemplo: `tu-nombre-2024`)
2. **Email:** Usa tu email personal
3. **Password:** Crea una contraseña segura
4. **Verificación:** Completa el captcha
5. Haz clic en **"Create account"**

### 1.3 Verificar email
1. Ve a tu email
2. Busca el email de GitHub
3. Haz clic en el enlace de verificación

**🎉 ¡Ya tienes cuenta en GitHub!**

---

## 📊 PASO 2: CONFIGURAR GOOGLE SHEETS API

Esto permite que nuestro programa escriba en tu hoja de Google Sheets automáticamente.

### 2.1 Ir a Google Cloud Console
1. Ve a: **https://console.cloud.google.com**
2. Inicia sesión con tu cuenta de Google
3. Si es tu primera vez, acepta los términos

### 2.2 Crear un nuevo proyecto
1. En la parte superior, haz clic en **"Select a project"**
2. Haz clic en **"NEW PROJECT"**
3. **Project name:** `Extractor-IA-Tools`
4. Haz clic en **"CREATE"**
5. Espera a que se cree (1-2 minutos)

### 2.3 Activar Google Sheets API
1. En el menú lateral, ve a **"APIs & Services"** → **"Library"**
2. Busca: `Google Sheets API`
3. Haz clic en **"Google Sheets API"**
4. Haz clic en **"ENABLE"**

### 2.4 Crear credenciales de servicio
1. Ve a **"APIs & Services"** → **"Credentials"**
2. Haz clic en **"+ CREATE CREDENTIALS"**
3. Selecciona **"Service account"**
4. **Service account name:** `extractor-ia`
5. **Service account ID:** se llena automáticamente
6. Haz clic en **"CREATE AND CONTINUE"**
7. En **"Role"**, selecciona **"Editor"**
8. Haz clic en **"CONTINUE"**
9. Haz clic en **"DONE"**

### 2.5 Descargar archivo de credenciales
1. En la lista de **"Service Accounts"**, haz clic en el email que se creó
2. Ve a la pestaña **"KEYS"**
3. Haz clic en **"ADD KEY"** → **"Create new key"**
4. Selecciona **"JSON"**
5. Haz clic en **"CREATE"**
6. **¡IMPORTANTE!** Se descargará un archivo JSON - **guárdalo bien**

**🔑 ¡Ya tienes las credenciales de Google!**

---


## 💻 PASO 3: CONFIGURAR EL REPOSITORIO EN GITHUB

Ahora vamos a subir nuestro código a GitHub para que se ejecute automáticamente.

### 3.1 Crear nuevo repositorio
1. Ve a **https://github.com**
2. Inicia sesión con tu cuenta
3. Haz clic en el botón verde **"New"** (o el ícono **+** arriba a la derecha)
4. **Repository name:** `extractor-herramientas-ia`
5. **Description:** `Extractor automático de herramientas de IA para Google Sheets`
6. Selecciona **"Public"** (es gratis)
7. ✅ Marca **"Add a README file"**
8. Haz clic en **"Create repository"**

### 3.2 Subir los archivos del proyecto
Ahora necesitas subir los archivos que te voy a proporcionar:

#### Opción A: Subir archivos desde la web (MÁS FÁCIL)
1. En tu repositorio, haz clic en **"uploading an existing file"**
2. Arrastra los archivos que te daré o haz clic en **"choose your files"**
3. Escribe en **"Commit changes"**: `Agregar extractor de herramientas IA`
4. Haz clic en **"Commit changes"**

#### Opción B: Crear archivos uno por uno
1. Haz clic en **"Create new file"**
2. Nombra el archivo como te indique
3. Copia y pega el contenido que te proporcione
4. Haz clic en **"Commit changes"**

### 3.3 Archivos que necesitas crear

**Archivo 1: `ai_tools_scraper_simple.py`**
- Este es el programa principal
- Te lo proporcionaré completo

**Archivo 2: `requirements_simple.txt`**
- Lista de librerías necesarias
- Te lo proporcionaré completo

**Archivo 3: `.github/workflows/daily_scraper.yml`**
- Configuración para que se ejecute automáticamente
- Te lo proporcionaré completo

---

## 🔐 PASO 4: CONFIGURAR CREDENCIALES SECRETAS

GitHub necesita acceso a tu Google Sheets, pero de forma segura.

### 4.1 Preparar el archivo de credenciales
1. Abre el archivo JSON que descargaste de Google (paso 2.5)
2. **Copia TODO el contenido** (desde la primera `{` hasta la última `}`)

### 4.2 Agregar secreto en GitHub
1. En tu repositorio de GitHub, ve a **"Settings"** (arriba)
2. En el menú lateral, haz clic en **"Secrets and variables"** → **"Actions"**
3. Haz clic en **"New repository secret"**
4. **Name:** `GOOGLE_CREDENTIALS`
5. **Secret:** Pega aquí TODO el contenido del archivo JSON
6. Haz clic en **"Add secret"**

**🔒 ¡Credenciales configuradas de forma segura!**

---

## 📅 PASO 5: CONFIGURAR LA AUTOMATIZACIÓN

### 5.1 Activar GitHub Actions
1. En tu repositorio, ve a la pestaña **"Actions"**
2. Si aparece un mensaje, haz clic en **"I understand my workflows, go ahead and enable them"**
3. Deberías ver el workflow **"Extractor Diario de Herramientas IA"**

### 5.2 Probar la primera ejecución
1. Haz clic en **"Extractor Diario de Herramientas IA"**
2. Haz clic en **"Run workflow"** (botón azul)
3. Haz clic en **"Run workflow"** en el menú que aparece
4. Espera 2-3 minutos y actualiza la página
5. Deberías ver una ejecución exitosa (✅)

### 5.3 Verificar que funciona
1. Ve a **https://sheets.google.com**
2. Deberías ver una nueva hoja llamada **"Herramientas IA"**
3. Dentro debería haber datos de herramientas de IA

**🎉 ¡Tu sistema está funcionando!**

---


## ⚙️ CONFIGURACIÓN FINAL Y PERSONALIZACIÓN

### 6.1 Cambiar la hora de ejecución
Por defecto, el sistema se ejecuta a las **10:00 AM hora española** todos los días.

**Para cambiar la hora:**
1. Ve a tu repositorio en GitHub
2. Abre el archivo `.github/workflows/daily_scraper.yml`
3. Haz clic en el ícono del lápiz (editar)
4. Busca la línea: `- cron: '0 9 * * *'`
5. Cambia el `9` por la hora que prefieras (en formato 24h, hora UTC)
   - Para las 8:00 AM España: `- cron: '0 7 * * *'`
   - Para las 12:00 PM España: `- cron: '0 11 * * *'`
   - Para las 6:00 PM España: `- cron: '0 17 * * *'`
6. Haz clic en **"Commit changes"**

### 6.2 Cambiar el nombre de la hoja de Google Sheets
1. Abre el archivo `ai_tools_scraper_simple.py`
2. Busca la línea que dice: `escribir_google_sheets(todas_herramientas)`
3. Cámbiala por: `escribir_google_sheets(todas_herramientas, "MI_NOMBRE_PERSONALIZADO")`
4. Guarda los cambios

### 6.3 Compartir tu hoja con otros
1. Ve a tu hoja de Google Sheets
2. Haz clic en **"Compartir"** (arriba a la derecha)
3. Cambia los permisos a **"Cualquier persona con el enlace"**
4. Selecciona **"Lector"** para que solo puedan ver
5. Copia el enlace y compártelo

---

## 🛠️ SOLUCIÓN DE PROBLEMAS

### ❌ Problema: "No se encontró archivo de credenciales"
**Solución:**
1. Verifica que creaste el secreto `GOOGLE_CREDENTIALS` en GitHub
2. Asegúrate de que copiaste TODO el contenido del archivo JSON
3. El secreto debe empezar con `{` y terminar con `}`

### ❌ Problema: "Permission denied" en Google Sheets
**Solución:**
1. Ve a Google Cloud Console
2. Busca tu service account (extractor-ia@...)
3. Copia el email del service account
4. Ve a tu Google Sheets
5. Haz clic en "Compartir"
6. Agrega el email del service account como "Editor"

### ❌ Problema: El workflow no se ejecuta automáticamente
**Solución:**
1. Ve a tu repositorio → Settings → Actions → General
2. En "Workflow permissions", selecciona "Read and write permissions"
3. Guarda los cambios
4. Ejecuta el workflow manualmente una vez

### ❌ Problema: No se extraen herramientas
**Solución:**
1. Los sitios web pueden cambiar su estructura
2. Ve a la pestaña "Actions" en GitHub
3. Revisa los logs de error
4. El sistema creará archivos de respaldo locales aunque falle Google Sheets

### ❌ Problema: Muchos duplicados
**Solución:**
1. El sistema ya tiene protección anti-duplicados
2. Si ves duplicados, puede ser porque los nombres son ligeramente diferentes
3. Puedes limpiar manualmente la hoja de vez en cuando

---

## 📊 MONITOREO Y MANTENIMIENTO

### 📈 Cómo ver si funciona correctamente
1. **GitHub Actions:** Ve a tu repositorio → Actions
   - Verde ✅ = Funcionó bien
   - Rojo ❌ = Hubo un error
2. **Google Sheets:** Revisa que se agreguen nuevas herramientas
3. **Archivos de respaldo:** Se crean automáticamente en el repositorio

### 🔄 Frecuencia de actualización
- **Por defecto:** Una vez al día
- **Puedes cambiar:** Editando el archivo `daily_scraper.yml`
- **Ejecución manual:** Siempre puedes ejecutarlo cuando quieras

### 💾 Respaldos automáticos
El sistema crea automáticamente:
- **Archivo CSV:** Con todas las herramientas extraídas
- **Archivo JSON:** Para uso técnico
- **Google Sheets:** Tu hoja principal

---

## 🎯 PRÓXIMOS PASOS Y MEJORAS

### 🚀 Mejoras que puedes hacer:
1. **Agregar más fuentes:** Modificar el código para incluir más sitios web
2. **Filtros personalizados:** Solo herramientas de ciertas categorías
3. **Notificaciones:** Recibir email cuando se encuentren herramientas nuevas
4. **Análisis:** Crear gráficos con las tendencias

### 🌟 Funcionalidades avanzadas (para el futuro):
- Traducción automática al español
- Clasificación automática por categorías
- Detección de herramientas trending
- Integración con otras plataformas

---

## 📞 SOPORTE Y AYUDA

### 🆘 Si necesitas ayuda:
1. **Revisa esta guía** completa primero
2. **Consulta la sección de problemas** comunes
3. **Revisa los logs** en GitHub Actions
4. **Busca en Google** el mensaje de error específico

### 📚 Recursos útiles:
- **GitHub Docs:** https://docs.github.com
- **Google Sheets API:** https://developers.google.com/sheets
- **Cron Schedule:** https://crontab.guru (para cambiar horarios)

---

## ✅ CHECKLIST FINAL

Antes de terminar, verifica que:

- [ ] ✅ Tienes cuenta en GitHub
- [ ] ✅ Creaste el proyecto en Google Cloud Console
- [ ] ✅ Activaste Google Sheets API
- [ ] ✅ Descargaste el archivo de credenciales JSON
- [ ] ✅ Creaste el repositorio en GitHub
- [ ] ✅ Subiste todos los archivos del proyecto
- [ ] ✅ Configuraste el secreto GOOGLE_CREDENTIALS
- [ ] ✅ Activaste GitHub Actions
- [ ] ✅ Ejecutaste el workflow manualmente la primera vez
- [ ] ✅ Verificaste que se creó la hoja de Google Sheets
- [ ] ✅ Viste que hay datos en la hoja

**🎉 ¡FELICITACIONES! Tu extractor automático está funcionando.**

---

## 🔮 CONCLUSIÓN

Has creado un sistema completamente automático que:

- ✅ **Funciona 24/7** sin que tengas que hacer nada
- ✅ **Es completamente gratis** usando servicios gratuitos
- ✅ **Se actualiza solo** todos los días
- ✅ **No tiene duplicados** gracias a la lógica inteligente
- ✅ **Crea respaldos** automáticamente
- ✅ **Es escalable** - puedes agregar más fuentes fácilmente

**Tu hoja de Google Sheets se convertirá en una base de datos actualizada de las mejores herramientas de IA del mundo.**

¡Disfruta de tu nuevo superpoder automatizado! 🚀

---

*Creado por Manus AI - Tu asistente para automatizar el mundo*

